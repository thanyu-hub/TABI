using UnityEngine;

public class UICameraFollower : MonoBehaviour
{
    public Transform cameraTransform;
    public float distanceFromCamera = 1.0f;
    public float heightOffset = -0.2f;
    public float followSpeed = 5.0f;

    private Vector3 targetPosition;

    void Update()
    {
        if (cameraTransform == null) return;


        targetPosition = cameraTransform.position + cameraTransform.forward * distanceFromCamera;
        targetPosition.y += heightOffset;


        transform.position = Vector3.Lerp(transform.position, targetPosition, Time.deltaTime * followSpeed);

        transform.rotation = Quaternion.LookRotation(transform.position - cameraTransform.position);
    }
}
