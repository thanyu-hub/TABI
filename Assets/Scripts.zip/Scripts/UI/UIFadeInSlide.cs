using UnityEngine;
using System.Collections;

public class UIFadeInSlide : MonoBehaviour
{
    public float fadeDuration = 0.5f;
    public float moveDistance = 0.2f;
    private CanvasGroup canvasGroup;
    private Vector3 startPosition;

    void Awake()
    {
        canvasGroup = GetComponent<CanvasGroup>();
        startPosition = transform.localPosition;
    }

    public void Play()
    {
        StartCoroutine(Animate());
    }

    private IEnumerator Animate()
    {
        float elapsed = 0f;
        Vector3 targetPosition = startPosition;
        Vector3 fromPosition = startPosition + Vector3.up * moveDistance;

        transform.localPosition = fromPosition;
        canvasGroup.alpha = 0f;

        while (elapsed < fadeDuration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / fadeDuration);

            transform.localPosition = Vector3.Lerp(fromPosition, targetPosition, t);
            canvasGroup.alpha = t;

            yield return null;
        }

        transform.localPosition = targetPosition;
        canvasGroup.alpha = 1f;
    }

    public void PlayFadeOut(System.Action onComplete = null)
{
    StartCoroutine(AnimateFadeOut(onComplete));
}

private IEnumerator AnimateFadeOut(System.Action onComplete)
{
    float elapsed = 0f;
    Vector3 startPos = transform.localPosition;
    Vector3 endPos = startPos + Vector3.up * moveDistance;

    while (elapsed < fadeDuration)
    {
        elapsed += Time.deltaTime;
        float t = Mathf.Clamp01(elapsed / fadeDuration);

        transform.localPosition = Vector3.Lerp(startPos, endPos, t);
        canvasGroup.alpha = 1f - t;

        yield return null;
    }

    transform.localPosition = endPos;
    canvasGroup.alpha = 0f;

    if (onComplete != null)
    {
        onComplete();
    }
}
}
