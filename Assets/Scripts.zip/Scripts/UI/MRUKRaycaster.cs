using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Meta.XR.MRUtilityKit;
using TMPro;

public class MRUKRaycaster : MonoBehaviour
{
    public Transform rayStartPoint;
    public float rayLength = 5f;
    public GameObject planePrefab; // Prefab for the final plane to be placed
    public Material previewMaterial; // Material for preview during dragging
    public MRUKAnchor.SceneLabels labelFilter; // Target surface type (e.g., floor, wall)

    public EffectMesh roomGuardianEffectMesh;

    public TextMeshPro debugText; // Debug text display

    private bool isLaycastMode = false; // Whether raycast mode is active

    private Vector3 startPoint; // Drag start point
    private Vector3 endPoint; // Drag end point
    private bool isDragging = false; // Whether dragging is in progress
    private GameObject previewPlane; // Plane for preview display
    private MRUKRoom room; // Current MRUK room information

    // private LineRenderer lineRenderer;

    private bool guardianVisible = false;

    public GameObject panelObject;
    public Transform canvasPanelTransform;

    public GameObject simulatorObject;

    public void activateRayCastMode()
    {
        Debug.Log("Raycast mode activated");
        if (roomGuardianEffectMesh != null && !guardianVisible)
        {
            roomGuardianEffectMesh.HideMesh = false;
            guardianVisible = true;
            debugText.gameObject.SetActive(true);
            isLaycastMode = true;
            // lineRenderer.gameObject.SetActive(true);
        }
    }

    public void deActivateRayCastMode()
    {
        Debug.Log("Raycast mode deactivated");
        if (roomGuardianEffectMesh != null && guardianVisible)
        {
            roomGuardianEffectMesh.HideMesh = true;
            guardianVisible = false;
            debugText.gameObject.SetActive(false);
            // lineRenderer.gameObject.SetActive(false);
            isLaycastMode = false;

            if (previewPlane != null)
            {
                Destroy(previewPlane);
                Debug.Log("Preview plane destroyed");
            }
        }
    }

    void Start()
    {
        debugText.gameObject.SetActive(false);
        // lineRenderer = gameObject.AddComponent<LineRenderer>();
        // lineRenderer.startWidth = 0.01f;
        // lineRenderer.endWidth = 0.01f;
        // lineRenderer.material = new Material(Shader.Find("Sprites/Default"));
        // lineRenderer.startColor = Color.red;
        // lineRenderer.endColor = Color.red;
    }

    void Update()
    {
        if (rayStartPoint == null || roomGuardianEffectMesh == null || isLaycastMode == false)
        {
            return;
        }
        activateRayCastMode();
        Debug.Log("Raycasting in progress...");

        room = MRUK.Instance.GetCurrentRoom();

        Ray ray = new Ray(rayStartPoint.position, rayStartPoint.forward);
        Debug.DrawRay(ray.origin, ray.direction * rayLength, Color.red);
        // lineRenderer.SetPosition(0, ray.origin);
        // lineRenderer.SetPosition(1, ray.origin + ray.direction * rayLength);

        bool hasHit = room.Raycast(ray, rayLength, LabelFilter.FromEnum(labelFilter), out RaycastHit hit, out MRUKAnchor anchor);
        if (hasHit)
        {
            Vector3 hitPoint = hit.point;
            Vector3 hitNormal = hit.normal;

            string label = anchor.AnchorLabels[0];

            debugText.transform.position = hitPoint;
            debugText.transform.rotation = Quaternion.LookRotation(-hitNormal);

            debugText.text = "ANCHOR = " + label;
        }

        if (OVRInput.GetDown(OVRInput.Button.One))
        {
            Debug.Log("Trigger pressed!");
            if (hasHit)
            {
                startPoint = hit.point;
                isDragging = true;
                Debug.Log($"Drag start point: {startPoint}");

                if (previewPlane == null)
                {
                    previewPlane = GameObject.CreatePrimitive(PrimitiveType.Quad);
                    previewPlane.GetComponent<Renderer>().material = previewMaterial;
                    Destroy(previewPlane.GetComponent<Collider>());
                    Debug.Log("Preview plane created");
                }
            }
            else
            {
                Debug.LogWarning("Drag start point not found (Raycast failed)");
            }
        }

        if (isDragging && OVRInput.Get(OVRInput.Button.One))
        {
            if (hasHit)
            {
                endPoint = hit.point;
                Debug.Log($"Dragging, current point: {endPoint}");
                UpdatePreviewPlane(startPoint, endPoint, hit.normal);
            }
            else
            {
                Debug.LogWarning("Raycast failed during dragging");
            }
        }

        if (isDragging && OVRInput.GetUp(OVRInput.Button.One))
        {
            Debug.Log("Trigger released!");
            isDragging = false;

            if (previewPlane != null)
            {
                Destroy(previewPlane);
                Debug.Log("Preview plane destroyed");
            }

            if (hasHit)
            {
                CreateFinalPanel(startPoint, endPoint, hit.normal);
                Debug.Log($"Final plane created: Center {(startPoint + endPoint) / 2}");
                deActivateRayCastMode();
            }
            else
            {
                Debug.LogWarning("Drag end point not found (Raycast failed)");
            }
        }
    }

    void UpdatePreviewPlane(Vector3 start, Vector3 end, Vector3 normal)
    {
        if (previewPlane == null)
        {
            previewPlane = GameObject.CreatePrimitive(PrimitiveType.Quad);
            previewPlane.GetComponent<Renderer>().material = previewMaterial;
            Destroy(previewPlane.GetComponent<Collider>());
            Debug.Log("Preview plane created");
        }

        Vector3 center = (start + end) / 2f;

        Vector3 right = Vector3.Cross(Vector3.up, normal);
        if (right.magnitude < 0.01f)
        {
            right = Vector3.Cross(Vector3.forward, normal);
        }
        right.Normalize();

        Vector3 up = Vector3.Cross(normal, right);
        up.Normalize();

        Vector3 delta = end - start;
        float width = Mathf.Abs(Vector3.Dot(delta, right));
        float height = Mathf.Abs(Vector3.Dot(delta, up));

        previewPlane.transform.position = center;
        previewPlane.transform.rotation = Quaternion.LookRotation(-normal, up);
        previewPlane.transform.localScale = new Vector3(width, height, 1f);

        Debug.Log($"Preview updated: center={center}, width={width}, height={height}");
    }

    void CreateFinalPanel(Vector3 start, Vector3 end, Vector3 normal)
    {
        Vector3 center = (start + end) / 2f;

        Vector3 right = Vector3.Cross(Vector3.up, normal);
        if (right.magnitude < 0.01f)
        {
            right = Vector3.Cross(Vector3.forward, normal);
        }
        right.Normalize();

        Vector3 up = Vector3.Cross(normal, right);
        up.Normalize();

        Vector3 delta = end - start;
        float width = Mathf.Abs(Vector3.Dot(delta, right));
        float height = Mathf.Abs(Vector3.Dot(delta, up));

        if (panelObject != null)
        {
            panelObject.transform.position = center;
            panelObject.transform.rotation = Quaternion.LookRotation(-normal, up);
            panelObject.transform.localScale = Vector3.one;

            if (canvasPanelTransform != null)
            {
                RectTransform canvasRect = canvasPanelTransform.GetComponent<RectTransform>();
                if (canvasRect != null)
                {
                    // Adjust the size of the CanvasPanel
                    canvasRect.sizeDelta = new Vector2(width, height);
                    Debug.Log($"Adjusting CanvasPanel size: {canvasRect.sizeDelta}");
                }
                else
                {
                    Debug.LogWarning("RectTransform not found on CanvasPanel!");
                }
            }
            else
            {
                Debug.LogWarning("CanvasPanel Transform is not set!");
            }
        }
        else
        {
            Debug.LogWarning("panelObject is not set!");
        }
    }
}
