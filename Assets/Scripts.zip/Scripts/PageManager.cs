using UnityEngine;
using UnityEngine.UI;

public class PageManager : MonoBehaviour
{
    public Button nextButton;
    public Button previousButton;

    // Sliders to disable
    public GameObject densitySlider;
    public GameObject centroidSlider;

    // Buttons to change functions
    public Button initButton;
    public Button stepButton;
    public Button resetButton;

    // References to your scripts
    public GameObject graphObject;
    public Data data;
    public GameObject bookManagerCanvas;

    public GameObject simulator;


    void Start()
    {
        nextButton.onClick.AddListener(SwitchPage);
        previousButton.onClick.AddListener(SwitchPage);
        SwitchPage();
    }

    void SwitchPage()
    {
        if (bookManagerCanvas.GetComponent<BookManager>().currentPage == 1)
        {
            // Disable sliders
            centroidSlider.SetActive(false);

            // Clear old listeners
            initButton.onClick.RemoveAllListeners();
            stepButton.onClick.RemoveAllListeners();
            resetButton.onClick.RemoveAllListeners();
            var kmeans = graphObject.GetComponent<ScatterPoints>();
            kmeans.ClearScene();
            var mlp = graphObject.GetComponent<MLPVisualization>();
            mlp.ClearScene();
            // Call methods from SVMCanvasVisualizer
            var svm = graphObject.GetComponent<SVMCanvasVisualizer>();
            initButton.onClick.AddListener(() => svm.Sample());
            stepButton.onClick.AddListener(() => svm.StepOne());
            resetButton.onClick.AddListener(() => {svm.ResetCanvas(); simulator.SetActive(false);});

        }
        else
        {
            if (bookManagerCanvas.GetComponent<BookManager>().currentPage == 0)
            {
                // Re-enable sliders
                centroidSlider.SetActive(true);

                // Clear old listeners
                initButton.onClick.RemoveAllListeners();
                stepButton.onClick.RemoveAllListeners();
                resetButton.onClick.RemoveAllListeners();
                var svm = graphObject.GetComponent<SVMCanvasVisualizer>();
                svm.ResetCanvas();
                // Call methods from ScatterPoints
                var kmeans = graphObject.GetComponent<ScatterPoints>();
                initButton.onClick.AddListener(() => kmeans.SamplePoints());
                stepButton.onClick.AddListener(() => kmeans.RunOneIteration());
                resetButton.onClick.AddListener(() => {kmeans.ClearScene(); simulator.SetActive(false);});
            }
            else
            {
                centroidSlider.SetActive(false);

                // Clear old listeners
                initButton.onClick.RemoveAllListeners();
                stepButton.onClick.RemoveAllListeners();
                resetButton.onClick.RemoveAllListeners();
                var svm = graphObject.GetComponent<SVMCanvasVisualizer>();
                svm.ResetCanvas();
                // Call methods from ScatterPoints
                var mlp = graphObject.GetComponent<MLPVisualization>();
                initButton.onClick.AddListener(() => mlp.SamplePoints());
                stepButton.onClick.AddListener(() => mlp.RunOneIteration());
                resetButton.onClick.AddListener(() => {mlp.ClearScene(); simulator.SetActive(false);});
            }
        }
    }
}
