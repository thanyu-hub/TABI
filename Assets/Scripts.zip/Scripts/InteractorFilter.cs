using UnityEngine;

public class InteractorFilter : MonoBehaviour
{

    public GameObject rayInteractorObject;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        // if (handGrabInteractor.HasGrabbedObject)
        // {
        //     // 何か掴んでいるならRayを無効化
        //     if (rayInteractorObject.activeSelf)
        //         rayInteractorObject.SetActive(false);
        // }
        // else
        // {
        //     // 掴んでいないならRayを有効化
        //     if (!rayInteractorObject.activeSelf)
        //         rayInteractorObject.SetActive(true);
        // }
    }
}
