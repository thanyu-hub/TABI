using UnityEngine;

public class MiddleThumbSwipeUIOpener : MonoBehaviour
{
    public OVRHand hand;
    public float swipeThreshold = 0.2f; // 20cm以上動いたら
    public float maxSwipeTime = 0.5f; // 0.5秒以内にスワイプ完了

    private Vector3 startSwipePos;
    private float swipeStartTime;
    private bool isTrackingSwipe = false;

    void Update()
    {
        if (hand == null || hand.PointerPose == null)
            return;

        bool thumbPinching = hand.GetFingerIsPinching(OVRHand.HandFinger.Thumb);
        bool middlePinching = hand.GetFingerIsPinching(OVRHand.HandFinger.Middle);

        Vector3 currentPos = hand.PointerPose.position;

        if (!isTrackingSwipe)
        {
            if (thumbPinching && middlePinching)
            {
                startSwipePos = currentPos;
                swipeStartTime = Time.time;
                isTrackingSwipe = true;
                Debug.Log("[MiddleThumbSwipeUIOpener] ピンチ検出、スワイプ開始準備");
            }
        }
        else
        {
            if (!(thumbPinching && middlePinching))
            {
                Debug.Log("[MiddleThumbSwipeUIOpener] ピンチ解除、スワイプキャンセル");
                isTrackingSwipe = false;
                return;
            }

            float elapsed = Time.time - swipeStartTime;
            float verticalMovement = startSwipePos.y - currentPos.y;

            Debug.Log($"[MiddleThumbSwipeUIOpener] スワイプ中: 時間 {elapsed:F2}s, 移動量 {verticalMovement:F3}");

            if (elapsed > maxSwipeTime)
            {
                Debug.Log("[MiddleThumbSwipeUIOpener] タイムアウトでスワイプキャンセル");
                isTrackingSwipe = false;
                return;
            }

            if (verticalMovement > swipeThreshold)
            {
                Debug.Log("[MiddleThumbSwipeUIOpener] 成功！ 親指と中指で下スワイプ検出！");
                OpenUI();
                isTrackingSwipe = false;
            }
        }
    }

    void OpenUI()
    {
        Debug.Log("[MiddleThumbSwipeUIOpener] UIを表示します！");
        // UI Canvasをアクティブにするなどの処理をここに書く
    }
}
